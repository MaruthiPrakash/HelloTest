package com.JavaPrograms;

public class RemoveWhiteSpaces {

    public static void main(String[] args) {
        String s = "Two Three";
        System.out.println(s.replaceAll("\\s+",""));
    }
}
