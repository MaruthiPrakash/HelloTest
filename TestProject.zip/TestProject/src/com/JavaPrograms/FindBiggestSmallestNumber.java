package com.JavaPrograms;

public class FindBiggestSmallestNumber {
    public static void main(String[] args) {
        int[] arr={10, 20, 30, 05, 40, 50, 60, 70, 100, 90};
        int smallestNum=arr[0];
        int largestNum=arr[0];
        int secondLargest = arr[1];
        for (int i=1; i < arr.length; i++) {
            if (arr[i] > largestNum) {
                //secondLargest = largestNum;
                largestNum=arr[i];
            } else if (arr[i] < smallestNum) {
                smallestNum=arr[i];
            }
        }
        System.out.println(smallestNum);
        System.out.println(largestNum);
        //System.out.println(secondLargest);
    }
}

