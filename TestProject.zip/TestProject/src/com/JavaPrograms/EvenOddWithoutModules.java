package com.JavaPrograms;

public class EvenOddWithoutModules {
    public static void main(String[] args) {
        int number=9;
        if ((number & 1) == 0) {
            System.out.println("Even");
        } else {
            System.out.println("Odd");
        }
    }
}
