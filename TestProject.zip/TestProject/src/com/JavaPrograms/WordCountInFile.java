package com.JavaPrograms;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class WordCountInFile {
    public static void main(String[] args) throws IOException {
        int wordsCount=0;
        int charsCount=0;
        int linesCount=0;
        BufferedReader bufferedReader=null;
        try {
            bufferedReader=new BufferedReader(new FileReader("C:\\Test\\sample.txt"));
            String currentLine=bufferedReader.readLine();

            while (currentLine != null) {
                linesCount++;
                String[] words=currentLine.split(" ");
                wordsCount=wordsCount + words.length;
                for (String word : words) {
                    charsCount=charsCount + word.length();
                }
                currentLine=bufferedReader.readLine();
            }
            System.out.println(charsCount);
            System.out.println(wordsCount);
            System.out.println(linesCount);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            bufferedReader.close();
        }
    }
}
