package com.JavaPrograms;

import com.sun.corba.se.spi.ior.IdentifiableFactoryFinder;
import com.sun.org.apache.bcel.internal.generic.ATHROW;

import javax.sound.midi.Soundbank;
import javax.swing.tree.ExpandVetoException;
import javax.xml.ws.Holder;

public class Test {
    public static void main(String[] args) {
        int s = 92 % 3;
        System.out.println(s + 1);
        System.out.println("This");
        System.out.println("This is our release...work");
        System.out.println("bbbb");
        System.out.println("");
        System.out.println("This is our...");
        System.out.println();
        System.out.println();
    }
}
