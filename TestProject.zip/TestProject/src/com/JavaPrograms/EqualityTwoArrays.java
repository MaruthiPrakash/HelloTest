package com.JavaPrograms;

public class EqualityTwoArrays {
    public static void main(String[] args) {
        int[] x1={10, 20, 30, 40};
        int[] x2={10, 20, 70, 40};
        boolean equalityOrNot=true;

        if (x1.length == x2.length) {
            for (int i=0; i < x1.length; i++) {
                if (x1[i] != x2[i]) {
                    equalityOrNot=false;
                }
            }
        } else {
            equalityOrNot=false;
        }

        if (equalityOrNot) {
            System.out.println("Both Arrays Equal...");
        } else {
            System.out.println("Bot Arrays not equal ....");
        }
    }
}
