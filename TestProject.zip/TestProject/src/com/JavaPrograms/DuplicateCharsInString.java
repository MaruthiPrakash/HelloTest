package com.JavaPrograms;

import com.dss.dataStructure.Stack;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class DuplicateCharsInString {

    public static void main(String[] args) {
        String str="Maruthi Prakash Barika";

        Map<Character, Integer> mapChar=new HashMap<>();
        char[] ch=str.toCharArray();

        for (char c : ch) {
            if (mapChar.containsKey(c)) {
                mapChar.put(c, mapChar.get(c) + 1);
            } else {
                mapChar.put(c, 1);
            }
        }

        Set<Character> sChar=mapChar.keySet();
        for (Character c1 : sChar) {
            if (mapChar.get(c1) > 1) {
                System.out.println(c1 + " :  " + mapChar.get(c1));
            }
        }

    }
}
