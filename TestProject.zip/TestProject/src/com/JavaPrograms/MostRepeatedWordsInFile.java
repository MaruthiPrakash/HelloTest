package com.JavaPrograms;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MostRepeatedWordsInFile {

    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader=null;
        Map<String, Integer> stringIntegerMap=new HashMap<>();
        try {
            bufferedReader=new BufferedReader(new FileReader("C:\\Test\\sample.txt"));
            String currentLine=bufferedReader.readLine();
            while (currentLine != null) {
                String[] words=currentLine.split(" ");
                for (String word : words) {
                    if (stringIntegerMap.containsKey(word)) {
                        stringIntegerMap.put(word, stringIntegerMap.get(word) + 1);
                    } else {
                        stringIntegerMap.put(word, 1);
                    }
                }
                currentLine=bufferedReader.readLine();
            }

            Set<String> data=stringIntegerMap.keySet();
            for (String sData : data) {
                if (stringIntegerMap.get(sData) > 1) {
                    System.out.println(sData);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            bufferedReader.close();
        }
    }
}


