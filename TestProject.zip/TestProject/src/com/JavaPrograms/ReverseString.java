package com.JavaPrograms;

public class ReverseString {
    public static void main(String[] args) {
        String s="Hello";
        char[] c1=s.toCharArray();
        for (int i=c1.length-1; i >= 0; i--) {
            System.out.println(c1[i]);
        }
    }
}
