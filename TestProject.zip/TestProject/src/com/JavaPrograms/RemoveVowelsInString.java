package com.JavaPrograms;

public class RemoveVowelsInString {
    public static void main(String[] args) {
        String s = "Maruthi Prekash Olau";
        String newString = s.replaceAll("[AEIOUaeiou]","");
        System.out.println(newString);
    }
}
