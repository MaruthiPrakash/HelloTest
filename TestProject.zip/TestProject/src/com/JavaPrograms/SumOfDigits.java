package com.JavaPrograms;

public class SumOfDigits {

    public static void main(String[] args) {
        int number=456;
        int sum=0;
        while (number != 0) {
            int lastDig=number % 10;
            sum=sum + lastDig;
            number=number / 10;
        }
        System.out.println(sum);
    }
}
