package com.java8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;


public class EmployeeSort {

    public static void main(String[] args) {
        TreeMap<Integer, String> emp = new TreeMap<Integer, String>((O1, O2) -> (O1 > O2) ? 1 : (O1 > O2) ? 0 : -1);
        emp.put(20, "BB");
        emp.put(10, "CC");
        emp.put(30, "AA");
        emp.put(50, "DD");
        System.out.println(emp);
    }
}
