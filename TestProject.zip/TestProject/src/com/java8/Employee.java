package com.java8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Employees {

    int id;

    public String getName() {

        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    String name;

    public int getId() {

        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    Employees(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public String toString() {
        return id + " " + name;
    }
}


public class Employee {
    public static void main(String[] args) {

        List<Employees> list = new ArrayList<>();
        list.add(new Employees(222, "BBB"));
        list.add(new Employees(333, "AAA"));
        list.add(new Employees(111, "CCC"));

        Collections.sort(list, (e1, e2) -> (e1.id > e2.id) ? 1 : (e1.id < e1.id) ? 0 : -1);

        //Collections.sort(list, (e1, e2) -> e1.name.compareTo(e2.name));


        System.out.println(list);


    }
}
