package com.java8;

public class TestLambda {

    public static void main(String[] args) {

        Runnable r = (() -> {
            System.out.println("Main Thread");
        });

        System.out.println("");

        System.out.println("Hello this is the we");

    Thread t = new Thread(r);
        t.start();
        System.out.println("Child Thread..");
}
}
