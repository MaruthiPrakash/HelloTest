package com.java2blog.dataStructures;

import java.lang.reflect.Array;

public class StackCustom {
    int size;
    int arr[];
    int top = -1;

    public StackCustom(int newSize) {
        this.size = newSize;
        this.arr = new int[newSize];
        this.top = -1;
    }


    public void push(int e) {
        if (!isFull()) {
            top++;
            arr[top] = e;
            System.out.println("Element inserted successfully...."+arr[top]);
        } else {
            System.out.println("No element inserted...because stack is full...");
        }
    }

    public int pop() {
        if (!isEmpty()) {
            int returnElement = top;
            top--;
            System.out.println("Popped Element..."+arr[returnElement]);
            return returnElement;
        } else {
            System.out.println("Array is empty..");
            return -1;
        }
    }

    public int peek() {
        if (!this.isEmpty()) {
            System.out.println("Peek element "+arr[top]);
            return arr[top];
        } else {
            return -1;
        }
    }

    private boolean isEmpty() {
        return (top == -1);
    }


    private boolean isFull() {
        return (size - 1 == top);
    }


    public static void main(String[] args) {
        StackCustom StackCustom = new StackCustom(5);
        StackCustom.pop();
        System.out.println("=================");
        StackCustom.push(10);
        StackCustom.push(30);
        StackCustom.push(50);
        StackCustom.push(40);
        System.out.println("=================");
        StackCustom.pop();
        StackCustom.pop();
        StackCustom.pop();
        StackCustom.pop();
        System.out.println("=================");
        StackCustom.peek();
    }
}
