package com.DesignPatterns;

import java.io.*;

/*
   This is Singleton Design Pattern testing
 */

public class DateUtilTest {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        DateUtil t = DateUtil.getInstance();

        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("C:\\Test\\abc.ser")));
        oos.writeObject(t);

        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("C:\\Test\\abc.ser")));
        t = (DateUtil) ois.readObject();

        DateUtil t1 = DateUtil.getInstance();
        System.out.println(t == t1);


    }
}
