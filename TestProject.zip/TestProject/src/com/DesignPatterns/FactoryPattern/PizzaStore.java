package com.DesignPatterns.FactoryPattern;

public class PizzaStore {

    public static Pizza orderPizza(String type) {
        Pizza p = PizzaFactory.getOrder(type);
        p.bake();
        p.prepare();
        p.cut();
        return p;
    }
}
