package com.DesignPatterns.FactoryPattern;

public class ChickenPizza implements Pizza {

    @Override
    public void bake() {
        System.out.println("Chicken baking");
    }

    @Override
    public void prepare() {
        System.out.println("Chicken preparing");
    }

    @Override
    public void cut() {
        System.out.println("Chicken cutting...");
    }
}
