package com.DesignPatterns.FactoryPattern;

public interface Pizza {
    void bake();
    void prepare();
    void cut();
}
