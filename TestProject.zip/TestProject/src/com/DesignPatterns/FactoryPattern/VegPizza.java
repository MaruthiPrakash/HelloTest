package com.DesignPatterns.FactoryPattern;

public class VegPizza implements Pizza {
    @Override
    public void bake() {
        System.out.println("Veg...Baking....");
    }

    @Override
    public void prepare() {
        System.out.println("Veg..Preparing");
    }

    @Override
    public void cut() {
        System.out.println("Veg..Cutting");
    }
}
