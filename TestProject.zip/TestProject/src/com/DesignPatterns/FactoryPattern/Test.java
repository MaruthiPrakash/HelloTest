package com.DesignPatterns.FactoryPattern;

public class Test {

    public static void main(String[] args) {
        Pizza p = PizzaStore.orderPizza("Chicken");
    }
}
