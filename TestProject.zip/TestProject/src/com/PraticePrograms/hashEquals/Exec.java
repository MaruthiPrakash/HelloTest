package com.PraticePrograms.hashEquals;

import java.util.HashMap;
import java.util.Map;

public class Exec {
    public static void main(String[] args) {
        Student s1 = new Student("H001");
        Student s2 = new Student("H001");
        System.out.println(s1.equals(s2));

        Map<Student,ReportCard> sMap = new HashMap<Student,ReportCard>();
        sMap.put(s1,new ReportCard());
        sMap.put(s2,new ReportCard());

        System.out.println(sMap.size());

    }
}
