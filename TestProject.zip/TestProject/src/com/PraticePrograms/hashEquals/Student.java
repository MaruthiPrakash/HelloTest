package com.PraticePrograms.hashEquals;

import java.util.Objects;

public class Student {

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Student student = (Student) o;
        return registrationNumber.equals(student.registrationNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(registrationNumber);
    }

    private String registrationNumber;

    public Student(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

   /* public boolean equals(Object o) {
        if (o != null && o instanceof Student) {
            String regNum = ((Student) o).getRegistrationNumber();
            if (regNum != null && regNum.equals(this.getRegistrationNumber())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return this.getRegistrationNumber().hashCode();
    }*/

}
