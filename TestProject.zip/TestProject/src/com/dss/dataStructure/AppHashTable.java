package com.dss.dataStructure;

public class AppHashTable {

    public static void main(String[] args) {
        HashTable table = new HashTable(19);
        table.insert("Ball");
        table.insert("Apple");
        table.insert("Ram");
        table.insert("Balu");
        table.insert("Mahen");
        table.insert("Dhoni");
        table.insert("Sharuk");
        table.insert("Salman");

        System.out.println("Inserted date" + table);

        System.out.println(table.findWord("Ram"));

    }
}
