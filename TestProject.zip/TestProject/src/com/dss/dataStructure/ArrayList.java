package com.dss.dataStructure;

import java.util.Arrays;

public class ArrayList<E> {

    private Object[] elementsData;
    private int initialCapacity=10;
    private int size;

    public ArrayList()
    {
        this.elementsData=new Object[initialCapacity];
    }

    public void add(E e) {

        if (size == initialCapacity) {
            ensureCapacity();
        }
        elementsData[size++]=e;
    }

    private void ensureCapacity() {
        int newCapacity=elementsData.length * 2;
        elementsData=Arrays.copyOf(elementsData, newCapacity);
    }

    public E get(int index) {
        if (index < 0 || index >= size - 1) {
            throw new IndexOutOfBoundsException();
        }
        return (E) elementsData[index];
    }

    public int remove(int index) {

        int elementsDatum= (int)elementsData[index];
        for (int i=0; i < size - 1; i++) {
            elementsData[i]=elementsData[i + 1];
        }
        size--;
        return elementsDatum;
    }

    public void display() {
        for (int i=0; i < elementsData.length; i++) {
            System.out.println(elementsData[i]);
        }
    }


    public static void main(String[] args) {
        ArrayList<Integer> s=new ArrayList<>();
        s.add(2);
        s.add(3);
        s.add(4);
        s.display();
        System.out.println(s.get(1));
        System.out.println(s.remove(1));
        s.display();
    }
}
