package com.dss.dataStructure;

public class AppStack {
    public static void main(String[] args) {
        Stack st = new Stack(10);
        st.push(10);
        st.push(20);
        st.push(30);
        st.push(40);

        while (!st.isEmpty()){
            long value = st.pop();
            System.out.println(value);
        }

    }
}
