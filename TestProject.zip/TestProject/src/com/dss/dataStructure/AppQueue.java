package com.dss.dataStructure;

public class AppQueue {
    public static void main(String[] args) {
        Queue sQueue = new Queue(4);
        sQueue.insert(10);
        sQueue.insert(20);
        sQueue.insert(30);
        sQueue.insert(40);
        /*sQueue.insert(99);
        sQueue.insert(100);
        sQueue.insert(97);
        sQueue.insert(100);*/


        sQueue.view();
        //sQueue.remove();

    }
}
