package com.dss.dataStructure.Heap;

public class Heap {
    private int maxSize;
    private Node[] heapArray;
    private int currentSize;

    public Heap(int size) {
        this.maxSize = size;
        this.currentSize = 0;
        this.heapArray = new Node[size];
    }

    public int getSize() {
        return currentSize;
    }

    public boolean isEmpty() {
        return (currentSize == 0);
    }

    public boolean insert(int key) {
        if (currentSize == maxSize) {
            return false;
        }

        Node newNode = new Node(key);
        heapArray[currentSize] = newNode;

        trickleUp(currentSize);
        currentSize++;
        return true;

    }

    private void trickleUp(int idx) {
        int parentIdx = (idx - 1) / 2;
        Node nodeToInsert = heapArray[idx];

        while (idx > 0 && heapArray[parentIdx].getKey() < nodeToInsert.getKey()) {
            heapArray[idx] = heapArray[parentIdx];
            idx = parentIdx;
            parentIdx = (parentIdx - 1) / 2;
        }
        heapArray[idx] = nodeToInsert;

    }

    public Node remove() {
        Node root = heapArray[0];
        currentSize--;
        heapArray[0] = heapArray[currentSize];
        trickleDown(0);
        return root;
    }

    private void trickleDown(int idx) {

        //Code has to be written here
    }

}
