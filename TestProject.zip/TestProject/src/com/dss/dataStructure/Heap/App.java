package com.dss.dataStructure.Heap;

public class App {
    public static void main(String[] args) {
        Heap sHeap = new Heap(10);
        sHeap.insert(7);
        sHeap.insert(6);
        sHeap.insert(10);
        sHeap.insert(89);
        sHeap.insert(72);
        sHeap.insert(76);
        sHeap.insert(78);
        sHeap.insert(34);



    }
}
