package com.dss.dataStructure;

public class Queue {
    private int maxSize;
    private long[] queueArray;
    private int front;
    private int rear;
    private int nItems;

    public Queue(int size) {
        this.maxSize = size;
        this.queueArray = new long[maxSize];
        this.front = 0;
        this.rear = -1;
        this.nItems = 0;
    }

    public void insert(long j) {
        if (rear == maxSize - 1) {
            rear=-1;
        }
        rear++;
        queueArray[rear]=j;
        nItems++;
    }

    public void view() {
        System.out.println("[");
        for (int i = 0; i < queueArray.length; i++) {
            System.out.println(queueArray[i] + " ");
        }
        System.out.println("]");
    }

    public long remove() {
        long temp = queueArray[front];
        front++;
        if (front == maxSize) {
            front = 0;
        }
        nItems--;
        return temp;
    }

    public long peekFront() {
        return queueArray[front];
    }

    public boolean isEmpty() {
        return (nItems == 0);
    }

    private boolean isFull() {
        return (nItems == maxSize);
    }
}
