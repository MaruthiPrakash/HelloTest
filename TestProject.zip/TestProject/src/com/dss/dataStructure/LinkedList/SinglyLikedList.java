package com.dss.dataStructure.LinkedList;

public class SinglyLikedList {

    private Node first;

    public SinglyLikedList() {
    }

    public boolean isEmpty() {
        return (first == null);
    }

    public void insertFirst(int data) {
        Node newNode=new Node();
        newNode.data=data;
        newNode.next=first;
        first=newNode;
    }

    public Node delete() {
        Node temp=first;
        first=first.next;
        return temp;
    }

    public void display() {
        Node current=first;
        while (current != null) {
            current.display();
            current=current.next;
        }
        System.out.println();
    }

    public void insertLast(int data) {
        Node current=first;
        while (current != null) {
            current=current.next;
        }
        Node newNode=new Node();
        newNode.data=data;
        current.next=newNode;
    }
}
