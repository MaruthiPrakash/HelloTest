package com.dss.dataStructure.LinkedList;

public class SingLLApp {
    public static void main(String[] args) {
        SinglyLikedList singlyLikedList=new SinglyLikedList();
        singlyLikedList.insertFirst(3);
        singlyLikedList.insertFirst(4);
        singlyLikedList.insertFirst(5);
        singlyLikedList.insertFirst(6);
        singlyLikedList.display();
        singlyLikedList.delete();
        singlyLikedList.display();
    }
}
