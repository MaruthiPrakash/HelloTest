package com.dss.dataStructure.LinkedList;

public class Node {
    public int data;
    public Node next;

    public void display() {
        System.out.println("{" + data + "}");
    }
}
