package com.dss.dataStructure.LinkedList;

public class Application {
    public static void main(String[] args) {
        Node nodeA=new Node();
        nodeA.data=4;
        Node nodeB=new Node();
        nodeB.data=3;
        Node nodeC=new Node();
        nodeC.data=7;
        Node nodeD=new Node();
        nodeD.data=8;
        nodeA.next=nodeB;
        nodeB.next=nodeC;
        nodeC.next=nodeD;
        System.out.println(nodesLength(nodeA));
        System.out.println(nodesLength(nodeB));

    }
    private static int nodesLength(Node node){
        int length = 0;
        Node current = node;
        while(current!=null){
            length++;
            current = current.next;
        }
        return length;
    }
}
