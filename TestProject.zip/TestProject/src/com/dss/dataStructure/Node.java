package com.dss.dataStructure;

public class Node {

    int key;
    String value;
    Node leftChild, rightChild;

    public Node(int key, String value) {
        super();
        this.key = key;
        this.value = value;
    }
}
