package com.dss.Algorithms;

public class ArithmeticOperations {
    public Integer add(Integer a, Integer b)
    {
        return a+b;
    }
}
