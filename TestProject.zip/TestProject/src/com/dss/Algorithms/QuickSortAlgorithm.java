package com.dss.Algorithms;

import java.util.Arrays;

public class QuickSortAlgorithm {

    public static void main(String[] args) {
        int[] x = {10, 7, 1, 3, 5, 8, 9, 6};
        //int[] x = {2,1,0,0,1,2,1,0,1};

        quickSort(x, 0, x.length - 1);
        System.out.println(Arrays.toString(x));
    }

    public static void quickSort(int[] inputArray, int start, int end) {
        if (start < end) {
            int pp = partition(inputArray, start, end);
            quickSort(inputArray, start, pp - 1); //left side sort
            quickSort(inputArray, pp + 1, end); //right side sort
        }
    }

    private static int partition(int[] inputArray, int start, int end) {
        int i = start - 1;
        int pivot = inputArray[end];
        for (int j = start; j <= end - 1; j++) {
            if (inputArray[j] <= pivot) {
                i++;
                int iVal = inputArray[i];
                int jVal = inputArray[j];
                inputArray[i] = jVal;
                inputArray[j] = iVal;
            }
        }

        int iVal = inputArray[i + 1];
        inputArray[end] = iVal;
        inputArray[i + 1] = pivot;
        return i + 1;
    }
}
