package com.dss.Algorithms;

import java.util.Hashtable;
import java.util.concurrent.Callable;

public class Test {
    public static void main(String[] args) {
        int d = 92% 4;
        int activePriority = d + 1;
        System.out.println(activePriority);
    }

}

